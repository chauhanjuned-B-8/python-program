# PTMAE — Project Documentation

**Student name:** Harvi  
**Roll number:** 56  
**Course:** Python Programming (Units 1–5)  
**Main file:** `main.py`

## 1. Project overview

PTMAE (Pure Python Transactional Micro-Banking & Audit Engine) is a command-line banking demonstration. It uses in-memory Python objects and plain-text files. It does not use a GUI, a database engine, third-party packages, or prohibited imports.

## 2. How to run

1. Keep `main.py` in a folder where Python can create text files.
2. Run `python main.py` (or run `main.py` from a Python IDE).
3. The program runs demonstrations for Units 1–5 and creates/updates `accounts.db`, `ledger.txt`, and `corrupted.log` in the current working directory.
4. At the end, type `YES` to open the interactive CLI or press Enter to finish.
5. In the CLI, use `HELP`, `INTEREST`, `PENALTY`, `GUARD`, or `EXIT`.

If `accounts.db` already exists, the program preserves it and attempts to update `Acc101`. Back up important data before testing file updates.

## 3. Architecture diagram

```text
                         +-------------------+
                         |     main.py       |
                         | Demonstration CLI |
                         +---------+---------+
                                   |
          +------------------------+------------------------+
          |                        |                        |
  +-------v-------+        +-------v-------+        +-------v-------+
  | Unit 1        |        | Unit 2        |        | Unit 3        |
  | State/loops   |        | Parser/closure|        | Reverse index |
  | Interest/guard|        | Lambdas        |        | Queue cleanup |
  +---------------+        +---------------+        +---------------+
          |                        |                        |
          +------------------------+------------------------+
                                   |
                    +--------------+--------------+
                    |                             |
             +------v-------+             +-------v--------+
             | Unit 4       |             | Unit 5         |
             | File update  |             | Account classes|
             | Error/ledger |             | Batch settlement|
             +------+-------+             +----------------+
                    |
        +-----------+-------------+
        |           |             |
   accounts.db  ledger.txt  corrupted.log
```

## 4. Unit-wise implementation

### Unit 1 — State control engine

- `run_banking_cli()` uses a `while` loop to continue until `EXIT`.
- `compound_interest()` uses repeated arithmetic and a loop; it does not import or use `math`.
- `calculate_penalty()` calculates a percentage penalty.
- `trajectory_guard()` halts when the balance falls below the safety threshold or a termination flag is encountered.

### Unit 2 — Parser and closure mechanics

- `parse_raw_log_line()` manually scans the string character by character. It supports quoted delimiters, doubled quote characters, empty fields, and trailing delimiters.
- `create_audit_filter()` returns a nested function that uses `nonlocal` to maintain a separate audit count.
- `build_positional_filters()` binds each loop position with `k=k`, avoiding late-binding errors.

### Unit 3 — Data inversion and in-place processing

- `build_reverse_index()` uses nested comprehensions to map service tags to sorted, unique `(account_id, branch_id)` tuples.
- `clean_transaction_queue()` mutates the same top-level list, converts tuples to lists, removes even integers from set elements, sorts embedded lists descending, and removes repeated top-level primitive values while preserving first occurrence.

### Unit 4 — File transaction and error logging

- Custom exceptions: `BaseSystemError`, `CorruptedRecordError`, `OutOfBoundsError`, and `InsufficientBalanceError`.
- `update_account_record()` opens `accounts.db` in `r+` mode, validates each record, updates the target record, and uses chunked seek/read/write operations to shift the file tail when record length changes.
- Valid updates are appended to `ledger.txt`; rejected records with line numbers are appended to `corrupted.log`.
- Processing counts are printed in a `finally` block.

### Unit 5 — Object-oriented engine

- `Account` contains private `__balance`, protected `_account_id`, and class attribute `total_accounts`.
- `SavingsAccount`, `CurrentAccount`, and `CreditAccount` inherit from `Account` and call `super().__init__()`.
- Each class overrides `process_settlement()` according to its settlement rule.
- `execute_batch_settlement()` catches failures separately for each account so processing continues.
- The demo shows valid mangled access (`_Account__balance`) and the expected `AttributeError` from `obj.__balance`.

## 5. State and scope tracking table

| Scope/type | Example in code | Purpose |
|---|---|---|
| Module-level constant | `STUDENT_NAME`, `ROLL_NO`, `SAFETY_THRESHOLD` | Fixed project details and threshold; not used to pass mutable state into closures |
| Local variable | `balance` in `compound_interest()` | Exists only during a function call |
| Enclosing variable | `audited_count` in `create_audit_filter()` | Stores count for the returned closure |
| `nonlocal` | `nonlocal audited_count` in `validate()` | Updates the enclosing function's counter |
| Lambda default binding | `lambda row, k=k, expected=expected: ...` | Preserves the intended loop position and criterion |
| Protected attribute | `self._account_id` | Intended for class/subclass use |
| Private attribute | `self.__balance` in `Account` | Demonstrates name mangling and encapsulation |
| Mangled attribute demonstration | `savings._Account__balance` | Shows Python's name-mangled attribute spelling |
| Class attribute | `Account.total_accounts` | Counts created account objects |

## 6. Module compliance checklist

- [x] Only allowed module imports (`datetime`); no third-party packages.
- [x] No `math`, `os`, `sys`, `csv`, `json`, `re`, database engine, or data-science imports.
- [x] Manual parser does not use `str.split()` or `str.replace()`.
- [x] Compound interest uses arithmetic and loop constructs.
- [x] Closure uses `nonlocal`; no global variable is used to pass closure state.
- [x] Lambda loop positions are bound using default arguments.
- [x] Reverse index uses nested comprehensions and sorted unique tuples.
- [x] Queue cleaner does not rebind the `data_list` parameter and preserves its identity.
- [x] File update uses `r+`, seek/read/write passes, and truncation where required.
- [x] File operations use `with` statements.
- [x] Custom exception hierarchy and per-account batch error handling are demonstrated.
- [x] Account inheritance, `super()`, private/protected/class attributes, and polymorphism are demonstrated.

## 7. Sample test outputs

The exact order of set values and reverse-index dictionary keys can vary because Python sets are unordered. Key results should include:

- Compound interest on 1000 at 5% for two periods: `102.5`
- Penalty on 500 at 2%: `10.0`
- Parser converts `"say ""hello"""` to `say "hello"`
- Queue identity remains unchanged after cleaning: `same id: True`
- All three custom exception classes inherit from `BaseSystemError`
- Savings settlement rejects any result below 1000; current accounts may use their configured overdraft; credit settlement adds 2.5% surcharge

## 8. Data format

`accounts.db` uses one record per line:

```text
Acc101,SAVINGS,5200.00
Acc102,CURRENT,800.00
Acc103,CREDIT,2500.00
```

The program creates this starter data only if `accounts.db` does not exist. A record with an incorrect field count, non-numeric balance, or unknown account type is treated as corrupted.
