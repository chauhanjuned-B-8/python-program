income=int(input("Enter monthly income"))

print(income)
if income>=100000:
    print("premium loan")

elif income>=50000:
    print("satndard loan")

elif income>=25000:
    print("basic loan")

else:
    print("not eligible")
