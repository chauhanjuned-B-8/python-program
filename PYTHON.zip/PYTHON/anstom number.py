num=int(input("Enter no:"))

sum=0
temp=num
while temp>0:
    re=temp%10
    sum+=re*re*re
    temp//=10
if(num==sum):
        print("It is anstone number: ")
else:
        print("It is not anstone number: ")
        