#nested loop.1
for i in range(1,26):
    for j in range(65,65+i):
        print(chr(j),end=" ")
    print()