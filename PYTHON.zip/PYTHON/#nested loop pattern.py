#nested loop.1
for i in range(1,5000):
    for j in range(1,1+i):
        print((j),end=" ")
    print()