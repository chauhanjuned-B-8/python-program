#PRINT first 10 nos
i=1
while i<=10:
    print(i)
    i=i+1
    #i++
    #i+=1
