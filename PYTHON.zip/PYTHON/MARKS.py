marks=int(input('Enter Marks:'))

print(marks)
if marks>=90:
    print("GRADE:A")

elif marks>=80:
    print("GRADE:B")

elif marks>=70:
    print("GRADE:C")

elif marks>=60:
    print("GRADE:D")
else:
    print("GRADE:F")
