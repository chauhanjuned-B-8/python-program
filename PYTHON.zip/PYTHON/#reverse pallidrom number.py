#reverse pallidrom number
num=int(input("Enter no:"))

rev=0
temp=num
while temp>0:
    re=temp%10
    rev= rev*10+re
    temp//=10
    print("reverse num",rev)