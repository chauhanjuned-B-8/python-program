sum=0
temp=num
while temp>0;
rev =temp%10
sum +=rev**3
temp //=10

if num==sum;