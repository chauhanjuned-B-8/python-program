#prime no
n=int(input("Enter no: "))
cnt=0
for i in range(1,1+n):
    if(n%i==0):
        cnt+=1
    if(cnt>2):
        break;
print(cnt)
if(cnt==2):
    print(n,"is prime number")
else:
    print(n,"is not prime number")