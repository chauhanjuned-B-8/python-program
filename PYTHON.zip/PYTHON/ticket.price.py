age=int(input('enter age: '))

print(age)
if age<=5:
    print("FREE")

elif age<=12:
    print("100")

elif age<=59:
    print("200")

else:
    print("150")
