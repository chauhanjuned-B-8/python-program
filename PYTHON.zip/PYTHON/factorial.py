i=1
ans=1
n=int(input("Enter Number"))
while i<=n:
    ans=ans*i
    i=i+1
    print(ans)
