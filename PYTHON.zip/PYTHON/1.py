

#factorial of given no
i=2
while i<=20:
    print(i)
    i+=2
    print("end")
          
